cp prediction_scribble3.png ../combined_train1/b1e3aeb0c56261c17eb71c747d116057b8da7e8c8a6845bdc01b2b3ee2299229/mask.png
cp prediction_scribble3.png ../combined_train1/1/mask.png
cp prediction_scribble3.png ../combined_train1/2/mask.png
cp prediction_scribble3.png ../combined_train1/3/mask.png
